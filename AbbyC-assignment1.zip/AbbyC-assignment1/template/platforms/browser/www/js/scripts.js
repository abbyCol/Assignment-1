var app = new Framework7({
    root: "#app",
    /* this is the app element */
    routes: [
        {
            path: '/page2/',
            url: 'pages/page2.html',

        },
        {
            path: '/page3/',
            url: 'pages/page3.html',
        },
        {
            path: '/page4/',
            url: 'pages/page4.html',
        },
        {
            path: '/page5/',
            url: 'pages/page5.html',
        },
        {
            path: '/page6/',
            url: 'pages/page6.html',
        }
    ]
});

var $$ = Dom7;

var mainView = app.views.create('.view-main');

var swiper = app.swiper.create('.swiper-container', {
    speed: 400,
    spaceBetween: 100
});


var newName;


$("#name").on("keypress", function (e) {
    if (e.keyCode == 13) {
        newName = $("#name").val();
        self.app.view.main.router.navigate('/page5/', {
            reloadCurrent: true
        });
        // pull the value from the input field in
    }
});


$$(document).on('page:init', '.page[data-name="page5"]', function () {

    $("#input-replace").html(newName);

});


